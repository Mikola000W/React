import './App.css';
import { useState } from 'react';

function App() {
  const [inputValue, setInputValue] = useState('');
  const [selectedRadio, setSelectedRadio] = useState('');

  const [list, setList] = useState([]);

  const handleChange = (e) => {
    setInputValue(e.target.value);
  };

  const handleRadioChange = (e) => {
    setSelectedRadio(e.target.value);
  };

  const handleSubmit = () => {
    if (inputValue.trim() !== '' && selectedRadio !== '') {
      setList([...list, { value: inputValue, radio: selectedRadio }]);
      setInputValue('');
      setSelectedRadio('');
    }
  };

  return (
    <div className="App">
      <p>Nazwa przesyłki</p>
      <input class="te" type="text" value={inputValue} onChange={handleChange} />
      <br></br>
      <div class='radio'>
        <input class="reaido" type="radio" name="type" value="S" checked={selectedRadio === "S"} onChange={handleRadioChange} />
        <label>Przesyłka S</label>
        <br></br>
        <input class="reaido" type="radio" name="type" value="M" checked={selectedRadio === "M"} onChange={handleRadioChange} />
        <label>Przesyłka M</label>
        <br></br>
        <input class="reaido" type="radio" name="type" value="L" checked={selectedRadio === "L"} onChange={handleRadioChange} />
        <label>Przesyłka L</label>
      </div>
      <br></br>

      <button onClick={handleSubmit}>Dodaj</button>
      <h1>Lista przesyłek</h1>
      <ul>
        {list.map((item, index) => (
          <li key={index}>
            Nazwa: 
            {item.value} <br></br>
            Rodzaj: 
            {item.radio}<br></br>
            <hr></hr>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
